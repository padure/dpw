<!doctype html>
<html lang="en">
<head>
    <?php include 'componente/header.view.php'; ?>
</head>
<body>

    <?php include "componente/scripts.view.php"; ?>
</body>
</html>